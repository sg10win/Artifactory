{{ header }}

.. _comparison:

===========================
Comparison with other tools
===========================

.. toctree::
    :maxdepth: 2

    comparison_with_r
    comparison_with_sql
    comparison_with_spreadsheets
    comparison_with_sas
    comparison_with_stata
